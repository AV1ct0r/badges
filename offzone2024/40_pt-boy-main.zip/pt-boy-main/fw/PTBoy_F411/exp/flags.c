#include "createflags.h"

void generateFlags(uint8_t* flag1, uint8_t* key, uint8_t* flag2){
	// This function generates flag1, flag2 and key
	// Flags format: "flag{..........................}" where "." is random value
	// Realization of this function is hidden
}

void getStatus(uint8_t* inpBuf, char* outBuf) {
	// Realization of this function is hidden
}

uint8_t isTaskSuccess(uint8_t task_num){
	// Realization of this function is hidden
	return 0;
}

void taskSuccess(uint8_t task_num){
	// Realization of this function is hidden
}

#ifndef SNAKE_H_
#define SNAKE_H_

#include "processState.h"
#include "main.h"

void snakeSetup();
ProcessState snakeExecute();
void snakeSetState(PushedButton handle);

#endif /* SNAKE_H_ */

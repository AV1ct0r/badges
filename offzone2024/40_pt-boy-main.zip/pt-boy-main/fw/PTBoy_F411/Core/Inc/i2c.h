#ifndef INC_I2C_H_
#define INC_I2C_H_

#include "main.h"

void i2cHandle(uint8_t *isBizoneShow);

#endif /* INC_I2C_H_ */

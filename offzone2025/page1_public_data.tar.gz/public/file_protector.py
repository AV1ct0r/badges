from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP, AES
from Crypto.Random import get_random_bytes
from Crypto.Hash import SHA256
from Crypto.Util.Padding import pad
import sys


def encrypt_file(input_file, output_file, public_key_file):
    aes_key = get_random_bytes(32) 
    
    with open(public_key_file, 'rb') as f:
        public_key = RSA.import_key(f.read())
    
    cipher_rsa = PKCS1_OAEP.new(public_key, hashAlgo=SHA256)
    encrypted_aes_key = cipher_rsa.encrypt(aes_key)
    
    iv = get_random_bytes(16)
    cipher_aes = AES.new(aes_key, AES.MODE_CBC, iv)
    
    with open(input_file, 'rb') as f:
        plaintext = f.read()
    
    padded_plaintext = pad(plaintext, AES.block_size)
    ciphertext = cipher_aes.encrypt(padded_plaintext)
    
    with open(output_file, 'wb') as f:
        f.write(len(encrypted_aes_key).to_bytes(4, 'big'))
        f.write(encrypted_aes_key)
        f.write(iv)
        f.write(ciphertext)

def main():
    filename = None
    if len(sys.argv) > 1:
        filename = sys.argv[1]
    else:
        print("[-] Usage: ./file_protector.py <file>")
        exit(-1)
    
    encrypt_file(filename, filename+'.enc', 'public.pem')
    
if __name__ == '__main__':
    main()